package be.intecBrussel;

public class StreamingAPI {
}
