package overerving_Car;

public class SUV extends Car{
    private String bullBar;
    public void spinRims(){

    }
}
