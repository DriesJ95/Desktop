package overerving_Car;

public class ElectricalCar extends Car {
    private String battery;
    public void chargeBattery(){

    }
}
