package overerving_Car;

public class Car {
    public String color;

    public void accelerate(){

    }

    public void slowDown(){

    }

    public void turnLeft(){

    }

    public void turnRight(){

    }
}
