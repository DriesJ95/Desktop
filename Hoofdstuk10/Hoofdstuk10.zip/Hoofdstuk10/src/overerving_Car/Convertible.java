package overerving_Car;

public class Convertible extends Car {
    private String sunroof;
    public void switchRoofMode(){

    }
}
