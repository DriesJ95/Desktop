package overerving_Car;

public class Sportscar extends Car {
    private String spoiler;
    public void setRaceMode(){

    }
}
