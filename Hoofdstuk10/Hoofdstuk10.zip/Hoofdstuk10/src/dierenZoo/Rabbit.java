package dierenZoo;

public class Rabbit extends Animal {
    public Rabbit(String name, double weight, String gender, int age, boolean happy, String motto) {
        super(name, weight, gender, age, happy, motto);
    }
}
