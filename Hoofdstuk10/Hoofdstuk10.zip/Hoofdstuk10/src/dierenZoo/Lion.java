package dierenZoo;

public class Lion extends Animal {
    public Lion(String name, double weight, String gender, int age, boolean happy, String motto) {
        super(name, weight, gender, age, happy, motto);
    }

}
